

import { AppRegistry } from 'react-native';
import AppointApp from './components/app';

 AppRegistry.registerComponent('AppointApp', () => AppointApp);
