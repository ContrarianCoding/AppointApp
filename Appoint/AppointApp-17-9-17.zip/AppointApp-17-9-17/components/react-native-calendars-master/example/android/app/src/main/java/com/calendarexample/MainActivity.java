package com.calendarexample;

import com.reactnativenavigation.controllers.SplashActivity;

public class MainActivity extends SplashActivity {

}
